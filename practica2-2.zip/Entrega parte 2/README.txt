Autor del fichero: Fernando Bermúdez

- En el directorio "mejores modelos" se pueden encontrar los ficheros de los modelos y los pesos de los mejores experimentos de PM y CNN

- En el directorio "prints experimentos" se pueden encontrar los ficheros para cada una de las redes usadas tanto en PM como CNN conteniendo la definición de la red y las secciones model.compile y model.fit, así como el resto de información que se muestra por pantalla con el código